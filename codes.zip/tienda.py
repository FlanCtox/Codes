Shake = 1000
CH = 500
Grani = 800
Malt = 1200
ShakeG = 400
ShakeCC = 300
CHD = 300
graniUH = 200
graniC = 950
MaltC = 300
total = 0

print("""
***********************
BIENVENIDO A SHAKETASTIC
***********************""")

cantidad = int(input("Cuantas querra comprar?"))



print("Que desea llevar?")


print("""
1) Shake
2) Cono Helado 
3) Granizado 
4) Malteada""")

opcion1 = int(input("Seleccione : "))


print("""
Querra añadir algo mas?

1) Shake grande
2) Shake chispas de chocolate
*******************************
3) Cono helado doble
******************************
4) Granizado ultra helado
5) Granizado caramelo
*******************************
6) Malteada crema

0) Salir

""")

opcion2 = int(input("seleccione : "))


if opcion1 ==1 and opcion2 ==1:
    print("A elegido añadir shake grande")
    total += ShakeG+Shake

elif opcion1 ==1 and opcion2 ==2:
    print("a elegido añadir chips de chocolate")
    total += ShakeCC+Shake

elif opcion1 ==2 and opcion2 ==3:
    print("A elegido cono helado doble")
    total += CHD+CH

elif opcion1 ==3 and opcion2 ==4:
    print("A elegido granizado ultra helado")
    total += graniUH+Grani

elif opcion1 ==3 and opcion2 ==4:
    print("a elegido granizado caramelo ")
    total = graniC+Grani

elif opcion1 ==4 and opcion2 ==6:
    print("a elegido malteada crema")
    total += MaltC+Malt

elif opcion1 ==1 and opcion2 ==0:
    print(" Shake normal")
    total += Shake

elif opcion1 ==2 and opcion2 ==0:
    pint("Cono normal")
    total += CH

elif opcion1 ==3 and opcion2 ==0:
    print(" granizado normal ")
    total += Grani

elif opcion1 ==4 and opcion2 ==0:
    print("malteada normal")
    total += Malt




print(f"""
****************************
Detalles de venta

***************************

el total a pagar es de {total*cantidad}




""")
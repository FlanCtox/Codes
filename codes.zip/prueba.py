#VARIABLES
TH=15000
TM=13000
TC=17000
#CONTADORES
CTH=0
CTM=0
CTC=0
#TOTALES
total=0
totaldesc=0 

while True:
    print(f"""
    --------------------------------
    Bienvenido a Un SHOCK DE AZUCAR
    --------------------------------
    1) Torta Holandesa : ${TH}
    2) Torta MilHojas  : ${TM}
    3) Torta Chocolate : ${TC}

    4)Total
    0)Salir""")
    opcion = int(input("Seleccione "))

    if opcion>=0 and opcion<=4:

        if opcion==1:
            print(f"Torta Holandesa : {TH}")
            CTH+=1
            total+=TH
        elif opcion==2:
            print(f"Torta MilHojas : {TM}")
            CTM+=1
            total+=TM
        elif opcion==3:
            print(f"Torta de Chocolate : {TC}")
            CTC+=1
            total+=TC
        elif opcion==0:
            print("Gracias bai")
        elif opcion==4:
            desc = str.upper(input(" ¿estas de cumpleaños? S/N "))
            if desc=="S":
                print(f"{CTH} Tortas Holandesas   : ${CTH*TH}")
                print(f"{CTM} Tortas MilHojas     : ${CTM*TM}")
                print(f"{CTC} Tortas de Chocolate : ${CTC*TC}")
                total = (CTH*TH)+(CTM*TM)+(CTC*TC)
                totaldesc = total*0.15

                print("--------------------------")
                print(f"Subtotal : {total} ")
                print(f"Total descuent : {totaldesc}")
                print("--------------------------")
                print(f"TOTAL A PAGAR : {total-totaldesc}")
                break
            elif desc=="N":
                print(f"{CTH} Tortas Holandesas   : ${TH*CTH} ")
                print(f"{CTM} Tortas MilHojas     : ${TM*CTM} ")
                print(f"{CTC} Tortas de Chocolate : ${TC*CTC} ")
                total = (TH*CTH)+(TM*CTM)+(TC*CTC)

                print("-------------------------------------")
                print(f"subtotal : ${total}")
                print(f"total descuento % : {totaldesc}")
                print("-------------------------------------")
                print(f"TOTAL A PAGAR : $ {total}")
                break

           
            
        else:
                print("ingrese opion valida")
    else:
            print("Ingrese opcion valida")
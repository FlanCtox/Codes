"""Tipo Torta	Precio
Holandesa	$15.000
Milhojas	$13.000
Chocolate	$17.000
"""
con1=0
con2=0
con3=0
ho=15000
mi=13000
ch=17000
total=0



while True:
    try:
        seleccion=int(input("""Seleccione tipo de torta :

        1)Holandesa   $15000
        2)Milhojas    $13000
        3)Chocolate   $17000
        4)Detalles
        5)Anular
        0)Salir: 
        """))
        if seleccion ==0:
            print("SALIR")
            break
        elif seleccion >=1 and seleccion<=3:
            if seleccion ==1:
                print(("Selecciono torta holandesa "))
                con1+=1
                total+=ho

            elif seleccion ==2:
                print(("Selecciono torta de milhojas "))
                con2+=1 
                total+=mi

            elif seleccion ==3:
                print(("Selecciono torta de chocolate "))
                con3+=1
                total+=ch
        elif seleccion==4:
            if input("¿usted esta de cumpleaños(S/N?").upper()=="S":
                descuento=total*0.15
                print(f"""DETALLES DE VENTA
                Shock de Azúcar
                -----------------------------------------
                {con1} torta Holandesa\t ${con1*ho}
                {con2} torta Milhojas\t ${con2*mi}
                {con3} torta Chocolate\t ${con3*ch}
                -----------------------------------------
                Subtotal\t ${total}
                Descuento 15%\t ${descuento}
                -----------------------------------------
                Total a pagar\t ${total-descuento}

                """)

            else:
                print(f"""DETALLES DE VENTA
                Shock de Azúcar
                -----------------------------------------
                {con1} torta Holandesa\t ${con1*ho}
                {con2} torta Milhojas\t ${con2*mi}
                {con3} torta Chocolate\t ${con3*ch}
                -----------------------------------------
                Subtotal\t ${total}
                Descuento 15%\t $0
                -----------------------------------------
                Total a pagar\t ${total}

                """)
        elif seleccion==5:
            print("Selecciono Anular ")
            con1=0
            con2=0
            con3=0
            ho=15000
            mi=13000
            ch=17000
            total=0
        else:
            print("Opcion invalida")  
    except:
        print("ERROR ERROR ERROR")









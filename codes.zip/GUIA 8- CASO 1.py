import msvcrt #detener
import os #limpiar pantalla 
import time #esperar segundos 


va = 0
vf = 0
vm = 0
vn = 0


#presentamos el sistema
while True:
    try:
        print("\033[32m <<PRESIONE UNA TECLA PARA CONTINUAR>>\033[0m")
        msvcrt.getch()
        os.system("cls")
        print("""
        SISTEMA DE VOTACIONES 
        *********************
        1)aquaman
        2) flecha verde
        3) Mujer maravilla
        0) Salir     """)
        opcion = int(input("Seleccione : "))

        if opcion ==1:
            print("Voto para aquaman")
            va +=1 
        elif opcion == 2:
            print("Voto para flecha verde")
            vf +=1
        elif opcion == 3:
            print("Voto para mujer maravilla")
            vm +=1
        elif opcion == 0:
            break
        else:
            print("Voto no valido: Nulo")
            vn += 1
    except:
        print("\033[31m Error en el sistema \033[0m")
        vn +=1

os.system("cls")
print("Cargando resultados.")
time.sleep(3)
os.system("cls")
print("Cargando resultados..")
time.sleep(3)
os.system("cls")
print("Cargando resultados...")
time.sleep(3)
os.system("cls")

#DETALLE RESULTADOS
print(f"""
RESULTADOS
----------
aquaman
flecha verde 
mujer maravilla
nulos

""")
import colorama
import msvcrt
import os



filas = 4
columnas = 6
cine = numpy.empty([filas, columnas], object)
letras = ["A","B","C","D"]



while True:
    print(f"{Fore.GREEN}{Back.BLUE}<<PRESIONE UNA TECLA PARA CONTINUAR>>{Back.RESET}{Fore.BLACK}")
    msvcrt.getch()
    os.system('cls')

    print(F"""
    {Fore.YELLOW}_____________________
    {Fore.BLUE}{Style.BRIGHT}📽 ENTRADAS CINE HOY🎬 {Style.RESET_ALL}  
    {Fore.YELLOW}_____________________{Fore.BLACK}
    1) Ver cine
    2) Comprar entrada
    3) Eliminar entrada
    4) Lsitado de asientos disponibles
    0) Salir """)
    opcion = int(input("Seleccione : "))

    if opcion == 0:
        break
    elif opcion == 1:
        print(f"{Fore.MAGENTA}VER CINE{Fore.RESET}")
        #Dibujar cine 
        print(f"{Fore.YELLOW}           PANTALLA{Fore.RESET}")
        print("   ⬛⬛⬛⬛⬛⬛⬛⬛⬛⬛⬛")
        print("    1   2   3   4   5   6")
        for x in range(filas):
            print(f" {letras[x]}", end="")
            for y in range(columnas):
                if cine[x,y]==None:
                    print(" ⚪ ",end="")
                else:
                    print(" 🔴 ",end="")
            print("")
        #Fin dibujar cine 
    elif opcion == 2:
        print(f"{Fore.MAGENTA}COMPRAR ENTRADA{Fore.RESET}")
        f = input("Que fila desea? (A-B-C-D) ").upper()
        while not f in (letras):
            f = input("INVALIDO!!!  Que fila desea? (A-B-C-D) : ").upper()
        C = int(input("Que columna desea? (1-6) : "))-1
        while C>5 or C<0:
            C = int(input("INVALIDO!!! Que columna desea? (1-6) : "))-1
            
        print(f"Asiento seleccionado : {letras.index(f)} {C}")
        if cine[letras.index(f),(C)] == None:
            cine[letras.index(f),(C)] = "x"
            print(F"{Fore.GREEN}Asiento vendido{Fore.RESET}")
        else:
            print(F"{Fore.RED}Asiento ocupado{Fore.RESET}")

    elif opcion == 3:
        print(f"{Fore.MAGENTA}ELIMINAR ENTRADA{Fore.RESET}")
        f = input("Ingrese la fila? (A-B-C-D) ").upper()
        while not f in (letras):
            f = input("INVALIDO!!!  Ingrese fila? (A-B-C-D) : ").upper()
        C = int(input("Ingrese columna desea? (1-6) : "))-1
        while C>5 or C<0:
            C = int(input("INVALIDO!!! Ingrese columna (1-6) : "))-1
        if cine[letras.index(f),(C)] == "x" :
            cine[letras.index(f),(C)] = None
            print("Entrada eliminada")
        else:
            print("Asiento aun no comprado") 

    elif opcion == 4:
        print(f"{Fore.MAGENTA}LISTADO DE ASIENTOS DISPONIBLES{Fore.RESET}")

    else:
        print(f"{Fore.MAGENTA}OPCION NO VALIDA{Fore.RESET}")
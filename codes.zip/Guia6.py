#churrasco $1.500
#Lomito $1.400
#Barros lucos $1800

con1 = 0
con2 = 0
con3 = 0
total = 0
churr = 1500
Lom = 1400
BarrLu = 1800


while True:
    print("""
***********************************************
          Bienvenido a Vida Con Sabor
***********************************************
 Seleccione con numeros que desea llevar
1) Churrasco
2) Lomito
3) Barros Lucos
0) salir""")
    opcion = int(input())
    if opcion == 1:
        print("A elegido Churrasco")
        con1+=1
        total+=churr
    if opcion == 2:
        print("a elegido lomito")
        con2+=1
        total+=Lom
    if opcion == 3:
        print("A elegido Barros Lucos")
        con3+=1
        total+=BarrLu
    if opcion == 0:
        print("VUELVA PRONTO :) ")
        break
    else:
        print("Vuelva a seleccionar porfavor")


import msvcrt
print("precione cualquier tecla para continuar....")
msvcrt.getch()

print(f"""
******************************************
Detalles de Venta
*****************************************
Cantidad de churrascos : {con1}
Cantidad de Lomito     : {con2}
Cantidad de Barros Lucos : {con3}

Total A pagar : {total}


""")

    



    
    
    
 
 






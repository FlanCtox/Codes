#VARIABLES
TH=15000
TM=13000
TC=17000
#CONTADORES
CTH=0
CTM=0
CTC=0
#TOTALES
total=0
totaldesc=0
while True:
    try:
        print("""
        **********
        PASTELERIA SHOCK DE AZUCAR
        **********
        TORTAS DISPONIBLES:
        
        1) TORTA HOLANDESA : $15000
        2) TORTA MILHOJA   : $13000
        3) TORTA CHOCOLATE : $17000

        4) TOTAL
        0) REINICIAR/SALIR COMPRA
        """)
        opc=int(input("SELECCIONE : "))
        if opc>=0 and opc<=4:
            if opc ==1:
                print("TORTA HOLANDESA")
                print(f"VALOR : ${TH}")
                total=TH
                CTH+=1
            elif opc==2:
                print("TORTA MILHOJA")
                print(f"VALOR : ${TM}")
                total=TM
                CTM+=1
            elif opc==3:
                print("TORTA CHOCOLATE")
                print(f"VALOR : ${TC}")
                total=TC
                CTC+=1
            elif opc==4: #totalizo
                desc = str.upper(input(" ES SU CUMPLEAÑOS (S/N) : "))
                if desc=="S":#15%desc
                    print("TOTAL PEDIDO")
                    print("--------------------------------")
                    print(f"{CTH} TORTA HOLANDESA ${TH*CTH}")
                    print(f"{CTM} TORTA MILHOJA   ${TM*CTM}")
                    print(f"{CTC} TORTA CHOCOLATE ${TC*CTC}")
                    total=(TH*CTH)+(TM*CTM)+(TC*CTC)
                    totaldesc=total*0.15
                    print("--------------------------------")
                    print(f"SUBTOTAL      ${total}")
                    print(f"DESCUENTO 15% ${totaldesc}")
                    print("--------------------------------")
                    print(f"TOTAL A PAGAR ${total-totaldesc}")
                elif desc=="N":
                    print("TOTAL PEDIDO")
                    print("--------------------------------")
                    print(f"{CTH} TORTA HOLANDESA ${TH*CTH}")
                    print(f"{CTM} TORTA MILHOJA   ${TM*CTM}")
                    print(f"{CTC} TORTA CHOCOLATE ${TC*CTC}")
                    total=(TH*CTH)+(TM*CTM)+(TC*CTC)
                    print("--------------------------------")
                    print(f"TOTAL A PAGAR ${total}")

            
                else:
                    print("<<ERROR INGRESE OPCION VALIDA>>")
            else:
                print("<<ERROR INGRESE OPCION VALIDA>>")
        else:
            print("<<ERROR INGRESE OPCION VALIDA>>")
    except:
        print("<<ERROR INGRESE OPCION VALIDA>>")